import pygame
import sys
import pygame_menu

pygame.init()
surface = pygame.display.set_mode((510, 510))
pygame.display.set_caption("Война вирусов")


def start_the_game():
    size_block = 40
    margin = 10
    screen = pygame.display.set_mode((510, 510))
    green = (0,255,0)
    white = (255,255,255)
    red = (255,0,0)
    mas = [[0]*10 for i in range(10)]
    query = 0
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit(0)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                x_mouse, y_mouse = pygame.mouse.get_pos()
                print(f'x={x_mouse} y={y_mouse}')
                col = x_mouse // (margin+size_block)
                row = y_mouse // (margin+size_block)
                if mas[row][col]==0:
                    if query%2==0:
                        mas[row][col]='x'
                    else:
                        mas[row][col] = 'o'
                    query+=1
        for row in range(10):
            for col in range(10):
                if mas[row][col]=='x':
                    color = red
                elif mas[row][col] =='o':
                    color = green
                else:
                    color = white
                x = col*size_block+(col+1)*margin
                y = row * size_block + (row + 1) * margin
                pygame.draw.rect(screen, color, (x, y, size_block, size_block))
                if color==red:
                    pygame.draw.line(screen,white, (x,y), (x+size_block,y+size_block),3)
                    pygame.draw.line(screen, white, (x + size_block, y), (x, y + size_block), 3)
                elif color==green:
                    pygame.draw.circle(screen,white, (x+size_block//2,y+size_block//2), size_block//2-3,3)
        pygame.display.update()


menu = pygame_menu.Menu('Приветсвуем', 510, 510,
                       theme=pygame_menu.themes.THEME_DARK)

menu.add.button('Играть', start_the_game)
menu.add.button('Правила')
menu.add.button('Выйти', pygame_menu.events.EXIT)

menu.mainloop(surface)